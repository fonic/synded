Bullfrog Syndicate level files decoder
------------------------------

You need to specify a level file as parameter.
The program will allow you to import, export or view
 structures from the level file.

Usage: synleved <levfile>

Example:
synleved GAME01.DAT

This tool is mainly written to rework the level format.
You can use it to extract arrays from level file, then
 modify these arrays and import them again. After such
 modification, you can run the game and find out what
 you changed.

Note that program is rewriting the level on exit, so better
 work on copies of level files. To exit without saving,
 use Ctrl-Break, not Escape.

The source code files comes with Dev-C++ project files, so you can
 easily rebuild the source using Dev-C++ IDE. 

Export format
------
This program can export all arrays and entries from Level files
 into separate files. It is easier to modify these exported files,
 because they are smaller and have constant element size.


When you'll find whan a single value in an array means,
 you can name it in any of LEVELDATA_* structures,
 decreasing the number of unknown bytes to maintain
 structure length.

Version: 1.03
Updated BULCOMMN unit

Version: 1.00
First working one

Author:
Tomasz Lis
