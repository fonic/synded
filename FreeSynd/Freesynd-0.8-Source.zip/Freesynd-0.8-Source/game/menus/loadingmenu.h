/************************************************************************
 *                                                                      *
 *  FreeSynd - a remake of the classic Bullfrog game "Syndicate".       *
 *                                                                      *
 *   Copyright (C) 2005  Stuart Binge  <skbinge@gmail.com>              *
 *   Copyright (C) 2005  Joost Peters  <joostp@users.sourceforge.net>   *
 *   Copyright (C) 2006  Trent Waddington <qg@biodome.org>              *
 *                                                                      *
 *    This program is free software;  you can redistribute it and / or  *
 *  modify it  under the  terms of the  GNU General  Public License as  *
 *  published by the Free Software Foundation; either version 2 of the  *
 *  License, or (at your option) any later version.                     *
 *                                                                      *
 *    This program is  distributed in the hope that it will be useful,  *
 *  but WITHOUT  ANY WARRANTY;  without even  the implied  warranty of  *
 *  MERCHANTABILITY  or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU  *
 *  General Public License for more details.                            *
 *                                                                      *
 *    You can view the GNU  General Public License, online, at the GNU  *
 *  project's  web  site;  see <http://www.gnu.org/licenses/gpl.html>.  *
 *  The full text of the license is also included in the file COPYING.  *
 *                                                                      *
 ************************************************************************/

#ifndef LOADINGMENU_H
#define LOADINGMENU_H

#include "fs-utils/misc/timer.h"
#include "fs-engine/menus/menu.h"

/*!
 * This menu is in charge of loading the mission.
 */
class LoadingMenu : public Menu {
public:
    LoadingMenu(MenuManager *m);

    void handleTick(int elapsed);

protected:
    /*! This is a flag to load the mission only once.*/
    bool do_load_;
    /*! This timer is used to be sure we can see the loading screen.
     * We don't want the application to be too fast!
     */
    fs_utils::Timer timer_;
};

#endif
